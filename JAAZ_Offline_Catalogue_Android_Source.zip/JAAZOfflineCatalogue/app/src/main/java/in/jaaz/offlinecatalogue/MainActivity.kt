package in.jaaz.offlinecatalogue

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.regex.Pattern

data class CatalogProduct(
    val url: String, val title: String, val description: String,
    val imageUrl: String, val price: String, val category: String
)

class CatalogDb(context: Context) : SQLiteOpenHelper(context, "jaaz_catalogue.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE products(
            url TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL,
            image_url TEXT NOT NULL, price TEXT NOT NULL, category TEXT NOT NULL,
            updated_at INTEGER NOT NULL DEFAULT 0)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun save(p: CatalogProduct) {
        writableDatabase.insertWithOnConflict("products", null, ContentValues().apply {
            put("url", p.url); put("title", p.title); put("description", p.description)
            put("image_url", p.imageUrl); put("price", p.price); put("category", p.category)
            put("updated_at", System.currentTimeMillis())
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun all(): List<CatalogProduct> {
        val out = mutableListOf<CatalogProduct>()
        readableDatabase.rawQuery("SELECT url,title,description,image_url,price,category FROM products ORDER BY category,title", null).use { c ->
            while (c.moveToNext()) out += CatalogProduct(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5))
        }
        return out
    }
    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM products", null).use { c -> c.moveToFirst(); c.getInt(0) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = CatalogDb(this)
        setContent { CatalogueScreen(db) }
    }
}

private val knownCategories = listOf(
    "Bathroom Set", "Shower Panel", "Shower Set", "Multi-Function Shower", "Rain Shower",
    "Mixer-Diverter", "Body Jets", "Steam", "Smart Toilet", "Wall Hung Toilet",
    "Wash Basin", "Basin Faucet", "Floor Drain", "Kitchen Faucet", "Kitchen Sink",
    "Bathroom Accessories", "Head Shower", "Hand Shower", "Combo product", "EWC"
)

private fun fetchText(url: String): String {
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 15000
    conn.readTimeout = 20000
    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) JAAZOfflineCatalogue/1.0")
    conn.setRequestProperty("Accept", "text/html,application/xml,application/json,*/*")
    return try { conn.inputStream.bufferedReader().use { it.readText() } } finally { conn.disconnect() }
}

private fun unescape(s: String): String = s
    .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
    .replace("&lt;", "<").replace("&gt;", ">").replace("\\u0026", "&")
    .replace("\\/", "/").trim()

private fun meta(html: String, key: String): String {
    val patterns = listOf(
        """<meta[^>]+property=["']$key["'][^>]+content=["']([^"']*)["'][^>]*>""",
        """<meta[^>]+content=["']([^"']*)["'][^>]+property=["']$key["'][^>]*>""",
        """<meta[^>]+name=["']$key["'][^>]+content=["']([^"']*)["'][^>]*>"""
    )
    for (p in patterns) {
        val m = Pattern.compile(p, Pattern.CASE_INSENSITIVE).matcher(html)
        if (m.find()) return unescape(m.group(1) ?: "")
    }
    return ""
}

private fun categoryFor(url: String, title: String): String {
    val u = (url + " " + title).lowercase(Locale.ROOT)
    return knownCategories.firstOrNull { u.contains(it.lowercase(Locale.ROOT).replace(" ", "-")) || u.contains(it.lowercase(Locale.ROOT)) }
        ?: "Other Products"
}

private suspend fun syncProducts(context: Context, db: CatalogDb, status: (String) -> Unit) = withContext(Dispatchers.IO) {
    // Shopify sitemap index is the least intrusive public discovery route. It does not use the downloadable catalogue or contact page.
    val sitemap = fetchText("https://jaaz.in/sitemap.xml")
    val sitemapUrls = Regex("""<loc>(.*?)</loc>""", RegexOption.IGNORE_CASE).findAll(sitemap).map { unescape(it.groupValues[1]) }.toList()
    val productSitemaps = sitemapUrls.filter { it.contains("sitemap_products") }
    if (productSitemaps.isEmpty()) throw IllegalStateException("The website did not expose a product sitemap. Try again later or request a product export from JAAZ.")
    var processed = 0
    for (mapUrl in productSitemaps) {
        val xml = fetchText(mapUrl)
        val productUrls = Regex("""<loc>(.*?)</loc>""", RegexOption.IGNORE_CASE).findAll(xml)
            .map { unescape(it.groupValues[1].substringBefore("?")) }
            .filter { it.contains("/products/") }.distinct().toList()
        for (productUrl in productUrls) {
            try {
                val html = fetchText(productUrl)
                val title = meta(html, "og:title").ifBlank {
                    Regex("""<title[^>]*>(.*?)</title>""", RegexOption.IGNORE_CASE or RegexOption.DOT_MATCHES_ALL)
                        .find(html)?.groupValues?.get(1)?.replace(Regex("<[^>]+>"), "")?.let(::unescape).orEmpty()
                }.substringBefore(" – JAAZ").substringBefore(" | JAAZ").trim()
                if (title.isBlank()) continue
                val desc = meta(html, "og:description").ifBlank { meta(html, "description") }
                var image = meta(html, "og:image")
                if (image.startsWith("//")) image = "https:$image"
                val priceMatch = Regex("""(?:Rs\.?|₹)\s?[\d,]+(?:\.\d{1,2})?""", RegexOption.IGNORE_CASE).find(html)
                val price = priceMatch?.value?.replace("Rs.", "₹")?.trim().orEmpty()
                // Download product image into app-private storage so it can be shown offline.
                val localImage = if (image.isNotBlank()) {
                    try {
                        val dir = File(context.filesDir, "product-images").apply { mkdirs() }
                        val fileName = productUrl.substringAfterLast("/").substringBefore("?")
                            .replace(Regex("[^A-Za-z0-9_-]"), "_") + ".img"
                        val target = File(dir, fileName)
                        val imageConn = URL(image).openConnection() as HttpURLConnection
                        imageConn.connectTimeout = 12000
                        imageConn.readTimeout = 15000
                        imageConn.setRequestProperty("User-Agent", "Mozilla/5.0 JAAZOfflineCatalogue/1.0")
                        try {
                            imageConn.inputStream.use { input -> FileOutputStream(target).use { output -> input.copyTo(output) } }
                            "file://${target.absolutePath}"
                        } finally { imageConn.disconnect() }
                    } catch (_: Exception) { image }
                } else ""
                db.save(CatalogProduct(productUrl, title, desc, localImage, price, categoryFor(productUrl, title)))
                processed++
                if (processed % 10 == 0) status("Synced $processed products…")
            } catch (_: Exception) { /* one unavailable product should not stop the catalogue */ }
        }
    }
    if (processed == 0) throw IllegalStateException("No product pages could be imported. The website may block automated access.")
    status("Sync complete: $processed product pages saved.")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogueScreen(db: CatalogDb) {
    var refresh by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    var selected by remember { mutableStateOf<CatalogProduct?>(null) }
    var status by remember { mutableStateOf("First sync needs internet. After syncing, saved product details remain on this phone.") }
    var syncing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val products = remember(refresh) { db.all() }
    val categories = listOf("All") + products.map { it.category }.distinct().sorted()
    val shown = products.filter {
        (category == "All" || it.category == category) &&
        (query.isBlank() || it.title.contains(query, true) || it.description.contains(query, true))
    }
    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = {
                Column {
                    Text("JAAZ Offline Catalogue", fontWeight = FontWeight.Bold)
                    Text("${products.size} products saved on this device", style = MaterialTheme.typography.labelSmall)
                }
            })
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp)) {
                OutlinedTextField(query, { query = it }, label = { Text("Search products") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    var expanded by remember { mutableStateOf(false) }
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(category) }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false }) }
                        }
                    }
                    Button(enabled = !syncing, onClick = {
                        syncing = true
                        status = "Connecting to jaaz.in…"
                        scope.launch {
                            try { syncProducts(context, db) { status = it }; refresh++ }
                            catch (e: Exception) { status = "Sync failed: ${e.message ?: "Check internet and try again."}" }
                            finally { syncing = false }
                        }
                    }) { Text(if (syncing) "Syncing…" else "Sync") }
                }
                Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
                if (selected != null) {
                    TextButton(onClick = { selected = null }) { Text("← Back to products") }
                    AsyncImage(model = selected!!.imageUrl, contentDescription = selected!!.title, modifier = Modifier.fillMaxWidth().height(260.dp))
                    Text(selected!!.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    if (selected!!.price.isNotBlank()) Text(selected!!.price, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(selected!!.description.ifBlank { "No description was published on the product page." })
                    Spacer(Modifier.height(8.dp))
                    Text("Product page: ${selected!!.url}", style = MaterialTheme.typography.bodySmall)
                } else {
                    LazyColumn(Modifier.weight(1f)) {
                        items(shown, key = { it.url }) { p ->
                            Row(Modifier.fillMaxWidth().clickable { selected = p }.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                AsyncImage(model = p.imageUrl.ifBlank { null }, contentDescription = p.title, modifier = Modifier.size(100.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.title, fontWeight = FontWeight.SemiBold)
                                    Text(p.category, style = MaterialTheme.typography.labelSmall)
                                    if (p.price.isNotBlank()) Text(p.price)
                                    Text(p.description, maxLines = 3, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
                Text("Product information and images are owned by their respective rights holders. Use this app only in line with your dealer agreement and JAAZ permissions.", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(vertical = 6.dp))
            }
        }
    }
}
