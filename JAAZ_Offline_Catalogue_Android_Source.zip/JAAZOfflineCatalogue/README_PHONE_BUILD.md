# JAAZ Offline Catalogue — phone-only APK build

This is an Android Studio source project, not a compiled APK. It contains a cloud build workflow to compile a debug APK through GitHub Actions.

## What this starter does
- Native Android app with product search and category filter
- Product records saved in local SQLite
- Sync button attempts to discover public product pages through JAAZ's sitemap and save product title, description, image URL, and visible price locally
- Excludes the downloadable catalogue and contact page
- No login, cart, checkout, or payment features
- Optional future online updates: tap Sync while connected

## Build from an Android phone
1. Download and extract the ZIP using your phone's file manager.
2. Sign in at https://github.com and create a repository named `JAAZOfflineCatalogue`.
3. Upload the project files to the repository, including the hidden `.github/workflows/build-apk.yml`.
4. Commit to the `main` branch.
5. Open the repository's **Actions** tab. Run **Build JAAZ Catalogue APK**.
6. When the workflow succeeds, open its run and download the `JAAZ-Offline-Catalogue-APK` artifact.
7. Extract that artifact ZIP and tap `app-debug.apk` to install it. Android may ask you to allow installs from the browser/file manager.

## Important limitations
- The workflow has not been run or verified here.
- The first sync requires internet. It attempts to read public sitemap/product pages; the website may block this, change structure, or omit data. If it fails, request an authorized product data export from JAAZ or ask them for an API/feed.
- The app attempts to download each product image into app-private storage during sync, so successfully downloaded images can be viewed offline. If JAAZ blocks an image or changes its image format/URL, that image may remain online-only; verify the sync status and test in airplane mode.
- Product extraction is best-effort and may not include every variant/specification. Verify completeness against the official product list before relying on it for sales.
- A debug APK is for testing, not a signed production release.
- Use brand assets and product content only as allowed by your dealer agreement and the rights holder.
